let a, b;
a = 2;
b = 8;
const resultado = a * b;

console.log(`Variable a contiene ${a}`);
console.log(`Variable b contiene ${b}`);
console.log(`El producto de a por b es ${resultado}`);
