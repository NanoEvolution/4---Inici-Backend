const express = require('express')  
const app = express()  
app.use(express.urlencoded({ extended: true }))  
app.get('/convierte/', (req, res) => {  
 const euros = Number(req.query.euros)  
 const resultado = (euros / 1.21).toFixed(2)
 const cadena = `<h2> La cantidad introducida sin IVA es ${resultado}€</h2> 
 ` 
 res.send(cadena)  
})  
app.listen(5000, () => console.log('Server ready on localhost:5000')) 
